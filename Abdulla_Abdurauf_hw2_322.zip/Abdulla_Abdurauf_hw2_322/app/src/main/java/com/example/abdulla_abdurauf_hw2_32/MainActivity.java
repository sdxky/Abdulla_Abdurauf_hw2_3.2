package com.example.abdulla_abdurauf_hw2_32;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Player player1 = new Player(1, "Player One", new ArrayList<>(Arrays.asList(10, 20, 30)));
        Player player2 = new Player(2, "Player Two", new ArrayList<>(Arrays.asList(15, 25, 35)));
        Player player3 = new Player(3, "Player Three", new ArrayList<>(Arrays.asList(20, 30, 40)));
        Player player4 = new Player(4, "Player Four", new ArrayList<>(Arrays.asList(25, 35, 45)));
        Player player5 = new Player(5, "Player Five", new ArrayList<>(Arrays.asList(30, 40, 50)));
        Player player6 = new Player(6, "Player Six", new ArrayList<>(Arrays.asList(35, 45, 55)));
        Player player7 = new Player(7, "Player Seven", new ArrayList<>(Arrays.asList(40, 50, 60)));
        Player player8 = new Player(8, "Player Eight", new ArrayList<>(Arrays.asList(45, 55, 65)));
        Player player9 = new Player(9, "Player Nine", new ArrayList<>(Arrays.asList(50, 60, 70)));
        Player player10 = new Player(10, "Player Ten", new ArrayList<>(Arrays.asList(55, 65, 75)));

        ArrayList<Player> players = new ArrayList<>();
        players.add(player1);
        players.add(player2);
        players.add(player3);
        players.add(player4);
        players.add(player5);
        players.add(player6);
        players.add(player7);
        players.add(player8);
        players.add(player9);
        players.add(player10);

        players.forEach(player -> System.out.println(player.toString()));

        players.sort((p1, p2) -> p2.getNumber().compareTo(p1.getNumber()));

        System.out.println("\nОтсортированный список игроков:");
        players.forEach(player -> System.out.println(player.toString()));
    }
}
